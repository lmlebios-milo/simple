 
<!DOCTYPE html>
 <html>
 <head>
 	<title></title>
 </head>
 <body>

<?php

$adviser_full_name = "";

if(isset($_GET['adviser_id'])){

	$adviser_id = $_GET['adviser_id'];

	include("conn.php");
	$adviser_sql = "SELECT * FROM `tbl_adviser` WHERE adviser_id =". $adviser_id;
	$adviser_query = mysqli_query($conn, $adviser_sql);
	$adviser_row = mysqli_fetch_array($adviser_query);


	$adviser_full_name = $adviser_row['adviser_full_name'];

}


 ?>


 	<form action = "" method="POST">

 		<label>Adviser Name</label><br>
 		<input type="text" name="adviser_full_name" autocomplete="off" value = "<?php echo $adviser_full_name ?>"  required/> <br>

 		<input type = "submit" name = "save" value = "Save">

 	</form>
 
 </body>
 </html>