 <?php


 ?>

 <!DOCTYPE html>
 <html>
 
 <head>
 	<title></title>
 </head>
 <body>

<a href="adviser-new.php">new-adviser</a>

 	<table>

 		<tr>
 			<td>ID</td>
 			<td>Adviser</td>
 			<td></td>
 		</tr>

 		<?php


			include("conn.php");
			$aviser_sql = "SELECT * FROM `tbl_adviser` WHERE 1";
			$adviser_query = mysqli_query($conn, $aviser_sql);

			while($adviser_row = mysqli_fetch_array($adviser_query)){
				?>

			<tr>
 				<td><?php echo $adviser_row['adviser_id'] ?></td>
 				<td><?php echo $adviser_row['adviser_full_name'] ?></td>
 				<td>
 					<a href = "adviser-edit.php?adviser_id=<?php echo $adviser_row['adviser_id'] ?>">Edit</a>
 				</td>
 			</tr>

		<?php
			}


 		?>

 	</table>

 
 </body>

 </html>



