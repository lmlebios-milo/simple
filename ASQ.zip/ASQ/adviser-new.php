 
<!DOCTYPE html>
 <html>
 <head>
 	<title></title>
 </head>
 <body>

<?php

$adviser_full_name = "";

if(isset($_POST["save"])){

	$adviser_full_name = $_POST["adviser_full_name"];
	include("conn.php");
	$aviser_sql = "INSERT INTO `tbl_adviser` (`adviser_id`, `adviser_full_name`) VALUES (NULL, '".$adviser_full_name."');";
	$adviser_query = mysqli_query($conn, $aviser_sql);
	header("location:adviser-maintenance.php");

}

 ?>


 	<form action = "" method="POST">

 		<label>Adviser Name</label><br>
 		<input type="text" name="adviser_full_name" autocomplete="off" value = "<?php echo $adviser_full_name ?>"  required/> <br>

 		<input type = "submit" name = "save" value = "Save">

 	</form>
 
 </body>
 </html>